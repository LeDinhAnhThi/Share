﻿program PublicIPLogger;

uses
  Winapi.Windows,
  Winapi.WinSvc,
  System.SysUtils,
  System.Classes,
  Vcl.Forms,
  uMain in 'uMain.pas' {frmConfig},
  PublicIPLoggerService in 'PublicIPLoggerService.pas';

{$R *.res}

procedure ShowConfigForm;
begin
  Application.Initialize;
  Application.CreateForm(TfrmConfig, frmConfig);
  Application.Run;
end;

var
  ServiceTable: array [0..1] of TServiceTableEntry;
  Param: string;
begin
  if ParamCount = 0 then
  begin
    ServiceTable[0].lpServiceName := PWideChar(AServiceName);
    ServiceTable[0].lpServiceProc := @ServiceMain;
    ServiceTable[1].lpServiceName := nil;
    ServiceTable[1].lpServiceProc := nil;
    StartServiceCtrlDispatcher(ServiceTable[0]);
  end
  else
  begin
    Param := LowerCase(ParamStr(1));
    if (Param = '/i') or (Param = '/install') then
      InstallService
    else if (Param = '/u') or (Param = '/uninstall') then
      UninstallService
    else if (Param = '/c') or (Param = '/config') then
      ShowConfigForm
    else
      MessageBox(0, 'Các tham số hợp lệ:'#13#10 +
                '/install  - Cài đặt service'#13#10 +
                '/uninstall- Gỡ service'#13#10 +
                '/config   - Cấu hình service', 'Hướng dẫn', MB_ICONINFORMATION);
  end;
end.