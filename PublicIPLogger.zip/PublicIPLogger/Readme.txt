Giới thiệu chương trình:

Vietnamese
Public IP Logger Service là một dịch vụ Windows nhẹ, chạy nền, tự động ghi địa chỉ IP public của máy tính 
vào file log theo chu kỳ bạn cài đặt. 
Dịch vụ còn phản ứng với các sự kiện hệ thống như tạm dừng, thức dậy, đăng nhập, khóa màn hình để ghi lại thời điểm xảy ra.

Tính năng:

Lấy IP public qua HTTP (dùng WinHTTP API, không phụ thuộc thư viện ngoài).

Lưu file log vào thư mục bất kỳ hoặc thư mục của các dịch vụ đám mây phổ biến (Google Drive, OneDrive, Dropbox…).

Cấu hình linh hoạt qua file .ini, hỗ trợ giao diện đồ họa trực quan.

Hỗ trợ khởi động cùng Windows (AutoStart) nếu cần.

Xử lý sự kiện nguồn (suspend/resume) và sự kiện phiên (logon/logoff, lock/unlock) để ghi log chi tiết.

Timeout và khoảng cách kiểm tra có thể tùy chỉnh, tránh treo máy khi mất kết nối.

Dịch vụ phù hợp cho việc giám sát IP public thay đổi, hỗ trợ quản trị từ xa hoặc theo dõi hoạt động máy tính.

English
Public IP Logger Service is a lightweight Windows service that runs in the background, periodically logging the machine's public IP address to a file. It also reacts to system events such as suspend/resume, logon/logoff, and lock/unlock to record those moments.

Key Features:

Retrieves public IP via HTTP using WinHTTP API (no external libraries needed).

Saves log files to any folder or to popular cloud service folders (Google Drive, OneDrive, Dropbox, etc.).

Flexible configuration via .ini file, with an optional GUI.

Supports automatic startup with Windows (AutoStart).

Handles power events (suspend/resume) and session events (logon/logoff, lock/unlock) for detailed logging.

Customizable timeout and check interval to avoid hanging when network is down.

This service is ideal for monitoring public IP changes, remote administration, or tracking computer activity.