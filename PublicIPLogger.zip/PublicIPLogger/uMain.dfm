object frmConfig: TfrmConfig
  Left = 0
  Top = 0
  BorderStyle = bsDialog
  Caption = 'Public IP Logger Service Config'
  ClientHeight = 433
  ClientWidth = 520
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = True
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 16
    Top = 12
    Width = 489
    Height = 57
    Caption = ' Service '
    TabOrder = 0
    object chkAutoStart: TCheckBox
      Left = 16
      Top = 24
      Width = 273
      Height = 17
      Caption = 'Start with Windows (AutoStart)'
      TabOrder = 0
    end
  end
  object GroupBox2: TGroupBox
    Left = 16
    Top = 75
    Width = 489
    Height = 102
    Caption = ' Log '
    TabOrder = 1
    object lblLogFile: TLabel
      Left = 16
      Top = 28
      Width = 67
      Height = 13
      Caption = 'Log file name:'
    end
    object lblLogDir: TLabel
      Left = 16
      Top = 55
      Width = 96
      Height = 13
      Caption = 'Storage folder:'
    end
    object edtLogFileName: TEdit
      Left = 112
      Top = 24
      Width = 361
      Height = 21
      TabOrder = 0
      Text = 'PublicIPLog.txt'
    end
    object edtLogDir: TEdit
      Left = 112
      Top = 52
      Width = 281
      Height = 21
      TabOrder = 1
      Text = ''
    end
    object btnBrowseLogDir: TButton
      Left = 399
      Top = 50
      Width = 75
      Height = 25
      Caption = 'Browse...'
      TabOrder = 2
      OnClick = btnBrowseLogDirClick
    end
  end
  object GroupBox3: TGroupBox
    Left = 16
    Top = 183
    Width = 489
    Height = 174
    Caption = ' Network '
    TabOrder = 2
    object lblURL: TLabel
      Left = 16
      Top = 28
      Width = 36
      Height = 13
      Caption = 'URL IP:'
    end
    object lblDetect: TLabel
      Left = 16
      Top = 68
      Width = 80
      Height = 13
      Caption = 'Detection string:'
    end
    object lblInterval: TLabel
      Left = 16
      Top = 108
      Width = 90
      Height = 13
      Caption = 'Interval (minutes):'
    end
    object lblTimeout: TLabel
      Left = 16
      Top = 148
      Width = 58
      Height = 13
      Caption = 'Timeout (s):'
    end
    object edtURL: TEdit
      Left = 112
      Top = 24
      Width = 361
      Height = 21
      TabOrder = 0
      Text = 'http://api.ipify.org'
    end
    object edtDetect: TEdit
      Left = 112
      Top = 64
      Width = 361
      Height = 21
      TabOrder = 1
      Text = 'Current IP Address:'
    end
    object edtInterval: TEdit
      Left = 112
      Top = 104
      Width = 89
      Height = 21
      TabOrder = 2
      Text = '60'
    end
    object edtTimeout: TEdit
      Left = 112
      Top = 144
      Width = 89
      Height = 21
      TabOrder = 3
      Text = '10'
    end
  end
  object btnSave: TButton
    Left = 336
    Top = 376
    Width = 81
    Height = 25
    Caption = 'Save'
    TabOrder = 3
    OnClick = btnSaveClick
  end
  object btnCancel: TButton
    Left = 424
    Top = 376
    Width = 81
    Height = 25
    Caption = 'Cancel'
    TabOrder = 4
    OnClick = btnCancelClick
  end
end