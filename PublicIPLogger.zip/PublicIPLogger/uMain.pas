unit uMain;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, System.UITypes, Vcl.Graphics, Vcl.Controls, Vcl.Forms,
  Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls, IniFiles, PublicIPLoggerService,
  System.StrUtils;

type
  TfrmConfig = class(TForm)
    GroupBox1: TGroupBox;
    chkAutoStart: TCheckBox;
    GroupBox2: TGroupBox;
    lblLogFile: TLabel;
    edtLogFileName: TEdit;
    lblLogDir: TLabel;
    edtLogDir: TEdit;
    btnBrowseLogDir: TButton;
    GroupBox3: TGroupBox;
    lblURL: TLabel;
    edtURL: TEdit;
    lblDetect: TLabel;
    edtDetect: TEdit;
    lblInterval: TLabel;
    edtInterval: TEdit;
    lblTimeout: TLabel;
    edtTimeout: TEdit;
    btnSave: TButton;
    btnCancel: TButton;
    procedure btnSaveClick(Sender: TObject);
    procedure btnCancelClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnBrowseLogDirClick(Sender: TObject);
  private
    procedure LoadSettings;
    procedure SaveSettings;
  public
  end;

var
  frmConfig: TfrmConfig;

implementation

{$R *.dfm}

{$WARN SYMBOL_PLATFORM OFF}   // Suppress platform warnings (Windows only)

procedure TfrmConfig.FormCreate(Sender: TObject);
begin
  LoadSettings;
end;

procedure TfrmConfig.LoadSettings;
var
  Ini: TIniFile;
  IniPath: string;
  URLList: string;
begin
  IniPath := ChangeFileExt(ParamStr(0), '.ini');
  Ini := TIniFile.Create(IniPath);
  try
    URLList := Ini.ReadString('Network', 'IPCheckURLs',
      'http://api.ipify.org,http://checkip.dyndns.org,http://ipv4.icanhazip.com,http://checkip.amazonaws.com');
    edtURL.Text := URLList;
    edtDetect.Text := Ini.ReadString('Network', 'DetectPattern', '');
    edtInterval.Text := Ini.ReadString('Network', 'IntervalMinutes', '60');
    edtTimeout.Text := Ini.ReadString('Network', 'HTTPTimeoutSec', '10');

    edtLogFileName.Text := Ini.ReadString('Log', 'FileName', 'PublicIPLog.txt');
    edtLogDir.Text := Ini.ReadString('Log', 'Directory', '');

    chkAutoStart.Checked := Ini.ReadBool('Service', 'AutoStart', False);
  finally
    Ini.Free;
  end;
end;

procedure TfrmConfig.SaveSettings;
var
  Ini: TIniFile;
  IniPath: string;
  Interval, Timeout: Integer;
begin
  IniPath := ChangeFileExt(ParamStr(0), '.ini');
  Ini := TIniFile.Create(IniPath);
  try
    Ini.WriteBool('Service', 'AutoStart', chkAutoStart.Checked);

    Ini.WriteString('Log', 'FileName', edtLogFileName.Text);
    Ini.WriteString('Log', 'Directory', edtLogDir.Text);

    Ini.WriteString('Network', 'IPCheckURLs', edtURL.Text);
    Ini.WriteString('Network', 'DetectPattern', edtDetect.Text);
    Interval := StrToIntDef(edtInterval.Text, 60);
    Timeout := StrToIntDef(edtTimeout.Text, 10);
    Ini.WriteInteger('Network', 'IntervalMinutes', Interval);
    Ini.WriteInteger('Network', 'HTTPTimeoutSec', Timeout);
  finally
    Ini.Free;
  end;

  LoadConfig;
  MessageDlg('Configuration saved. Restart the service to apply changes.', mtInformation, [mbOK], 0);
  Close;
end;

procedure TfrmConfig.btnCancelClick(Sender: TObject);
begin
  Close;
end;

procedure TfrmConfig.btnSaveClick(Sender: TObject);
begin
  SaveSettings;
end;

procedure TfrmConfig.btnBrowseLogDirClick(Sender: TObject);
var
  FolderDialog: TFileOpenDialog;
begin
  FolderDialog := TFileOpenDialog.Create(nil);
  try
    FolderDialog.Options := [fdoPickFolders, fdoPathMustExist, fdoForceFileSystem];
    FolderDialog.Title := 'Select Log Storage Folder';
    if FolderDialog.Execute then
      edtLogDir.Text := FolderDialog.FileName;
  finally
    FolderDialog.Free;
  end;
end;

{$WARN SYMBOL_PLATFORM ON}   // Restore warnings for other units

end.