unit PublicIPLoggerService;

interface

uses
  Winapi.Windows, Winapi.WinSvc,
  System.SysUtils, System.Classes, System.SyncObjs, System.IniFiles,
  System.StrUtils, System.DateUtils, System.RegularExpressions, Winapi.ShellAPI,
  Registry, System.Types, IdHTTP, Winapi.WinInet;

type
  TConfig = record
    URLs: TStringDynArray;
    DetectPattern: string;
    IntervalMinutes: DWORD;
    TimeoutSec: DWORD;
    LogDir: string;
    LogFileName: string;
    AutoStart: Boolean;
  end;

var
  Config: TConfig;
  AServiceName: string = 'PublicIPLogger';
  ADisplayName: string = 'Public IP Logger Service';

procedure LoadConfig;
procedure ServiceMain(dwArgc: DWORD; lpszArgv: PLPWSTR); stdcall;
procedure InstallService;
procedure UninstallService;

implementation

var
  StopEvent: THandle;
  LogCS: TCriticalSection;
  LogQueue: TStringList;
  LogEvent: THandle;
  LastIP: string;
  LastIPFile: string;   // đường dẫn file lưu LastIP

const
  IPv6Pattern = '(' +
                '([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|' +
                '([0-9a-fA-F]{1,4}:){1,7}:|' +
                '([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|' +
                '([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|' +
                '([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|' +
                '([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|' +
                '([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|' +
                '[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|' +
                ':((:[0-9a-fA-F]{1,4}){1,7}|:)|' +
                'fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|' +
                '::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|' +
                '([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])' +
                ')';

  IPv4Pattern = '\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b';

function IsNetworkAvailable: Boolean;
var
  Flags: DWORD;
begin
  Result := InternetGetConnectedState(@Flags, 0);
end;

function ResolveCloudFolder(const CloudName: string): string;
var
  Reg: TRegistry;
  UserProfile: string;
begin
  Result := '';
  if CloudName = '' then Exit;

  UserProfile := GetEnvironmentVariable('USERPROFILE');
  if UserProfile = '' then
    UserProfile := ExtractFilePath(ParamStr(0));

  Reg := TRegistry.Create;
  try
    Reg.RootKey := HKEY_CURRENT_USER;

    if SameText(CloudName, 'GoogleDrive') then
    begin
      if Reg.OpenKey('\Software\Google\Drive', False) then
        Result := Reg.ReadString('UserEmail')
      else
        Result := '';
      if Result <> '' then
        Result := ExtractFilePath(ParamStr(0)) + 'GoogleDrive\'
      else
        Result := UserProfile + '\Google Drive';
    end
    else if SameText(CloudName, 'OneDrive') then
    begin
      if Reg.OpenKey('\Software\Microsoft\OneDrive', False) then
        Result := Reg.ReadString('UserFolder')
      else
        Result := UserProfile + '\OneDrive';
    end
    else if SameText(CloudName, 'Dropbox') then
    begin
      if Reg.OpenKey('\Software\Dropbox', False) then
        Result := Reg.ReadString('DropboxRoot')
      else
        Result := UserProfile + '\Dropbox';
    end
    else if SameText(CloudName, 'iCloudDrive') then
      Result := UserProfile + '\iCloudDrive'
    else if SameText(CloudName, 'Mega') then
      Result := UserProfile + '\MEGA'
    else if SameText(CloudName, 'Box') then
      Result := UserProfile + '\Box'
    else if SameText(CloudName, 'YandexDisk') then
      Result := UserProfile + '\YandexDisk'
    else if SameText(CloudName, 'pCloud') then
      Result := UserProfile + '\pCloud Drive'
    else if SameText(CloudName, 'Sync.com') then
      Result := UserProfile + '\Sync'
    else if SameText(CloudName, 'IceDrive') then
      Result := UserProfile + '\IceDrive'
    else
      Result := CloudName;
  finally
    Reg.Free;
  end;

  if (Result <> '') and (Result[Length(Result)] <> '\') then
    Result := Result + '\';
end;

procedure LoadConfig;
var
  Ini: TIniFile;
  IniPath: string;
  URLList: string;
  CloudFolder: string;
begin
  IniPath := ChangeFileExt(ParamStr(0), '.ini');
  Ini := TIniFile.Create(IniPath);
  try
    // Đưa các URL ổn định lên đầu
    URLList := Ini.ReadString('Network', 'IPCheckURLs',
      'http://checkip.amazonaws.com,' +
      'http://ipv4.icanhazip.com,' +
      'http://icanhazip.com,' +
      'http://ifconfig.me/ip,' +
      'http://api.ipify.org');
    Config.URLs := SplitString(URLList, ',');

    Config.DetectPattern := Ini.ReadString('Network', 'DetectPattern', '');
    Config.IntervalMinutes := Ini.ReadInteger('Network', 'IntervalMinutes', 60);
    Config.TimeoutSec := Ini.ReadInteger('Network', 'HTTPTimeoutSec', 30);

    Config.LogFileName := Ini.ReadString('Log', 'FileName', 'PublicIPLog.txt');
    CloudFolder := Ini.ReadString('Log', 'Directory', '');
    Config.LogDir := ResolveCloudFolder(CloudFolder);
    if Config.LogDir = '' then
      Config.LogDir := ExtractFilePath(ParamStr(0));

    Config.AutoStart := Ini.ReadBool('Service', 'AutoStart', False);
  finally
    Ini.Free;
  end;
end;

function GetLogFilePath: string;
begin
  Result := Config.LogDir + Config.LogFileName;
end;

procedure EnsureLogDirExists;
begin
  if (Config.LogDir <> '') and not DirectoryExists(Config.LogDir) then
    ForceDirectories(Config.LogDir);
end;

procedure RotateLogIfNeeded;
var
  FS: TFileStream;
  LogPath: string;
begin
  LogPath := GetLogFilePath;
  if not FileExists(LogPath) then Exit;
  FS := TFileStream.Create(LogPath, fmOpenRead);
  try
    if FS.Size > 10 * 1024 * 1024 then
    begin
      DeleteFile(PChar(LogPath + '.old'));
      RenameFile(LogPath, LogPath + '.old');
    end;
  finally
    FS.Free;
  end;
end;

procedure EnqueueLog(const S: string);
begin
  LogCS.Enter;
  try
    LogQueue.Add(FormatDateTime('yyyy-mm-dd hh:nn:ss', Now) + ' ' + S);
  finally
    LogCS.Leave;
  end;
  SetEvent(LogEvent);
end;

function LoggerThread(lp: Pointer): DWORD; stdcall;
var
  Handles: array[0..1] of THandle;
  WaitResult: DWORD;
  F: TextFile;
  I: Integer;
  LogPath: string;
begin
  Handles[0] := LogEvent;
  Handles[1] := StopEvent;

  while True do
  begin
    WaitResult := WaitForMultipleObjects(2, @Handles, False, INFINITE);
    if WaitResult = WAIT_OBJECT_0 then
    begin
      LogCS.Enter;
      try
        if LogQueue.Count = 0 then Continue;

        EnsureLogDirExists;
        RotateLogIfNeeded;
        LogPath := GetLogFilePath;
        AssignFile(F, LogPath);
        if FileExists(LogPath) then Append(F) else Rewrite(F);
        try
          for I := 0 to LogQueue.Count - 1 do
            Writeln(F, LogQueue[I]);
          LogQueue.Clear;
        finally
          CloseFile(F);
        end;
      finally
        LogCS.Leave;
      end;
    end
    else if WaitResult = WAIT_OBJECT_0 + 1 then
      Break
    else
      Break;
  end;
  Result := 0;
end;

function ExtractIPv6(const Text: string): string;
var
  Regex: TRegEx;
  Match: TMatch;
begin
  Result := '';
  try
    Regex := TRegEx.Create(IPv6Pattern);
    Match := Regex.Match(Text);
    if Match.Success then
      Result := Match.Value;
  except
    on E: Exception do
      EnqueueLog('EXCEPTION in ExtractIPv6: ' + E.Message);
  end;
end;

function ExtractIPv4(const Text: string): string;
var
  Regex: TRegEx;
  Match: TMatch;
begin
  Result := '';
  try
    Regex := TRegEx.Create(IPv4Pattern);
    Match := Regex.Match(Text);
    if Match.Success then
      Result := Match.Value;
  except
    on E: Exception do
      EnqueueLog('EXCEPTION in ExtractIPv4: ' + E.Message);
  end;
end;

function ExtractIPFromText(const Text, Pattern: string): string;
var
  PosIdx: Integer;
  Rest: string;
  Regex: TRegEx;
  Match: TMatch;
begin
  Result := '';
  try
    if Pattern <> '' then
    begin
      if (Length(Pattern) > 2) and (Pattern[1] = '/') and (Pattern[Length(Pattern)] = '/') then
      begin
        Regex := TRegEx.Create(Copy(Pattern, 2, Length(Pattern)-2));
        Match := Regex.Match(Text);
        if Match.Success then
          Result := Match.Value;
      end
      else
      begin
        PosIdx := System.Pos(Pattern, Text);
        if PosIdx > 0 then
        begin
          Rest := Copy(Text, PosIdx + Length(Pattern), MaxInt);
          Result := ExtractIPv6(Rest);
          if Result = '' then
            Result := ExtractIPv4(Rest);
        end;
      end;
    end
    else
    begin
      Result := ExtractIPv6(Text);
      if Result = '' then
        Result := ExtractIPv4(Text);
    end;
  except
    on E: Exception do
    begin
      EnqueueLog('EXCEPTION in ExtractIPFromText: ' + E.Message);
      Result := '';
    end;
  end;
end;

// Lưu IP cuối cùng vào file để duy trì qua các lần worker restart
procedure SaveLastIPToFile;
var
  F: TextFile;
begin
  if LastIPFile = '' then Exit;
  try
    AssignFile(F, LastIPFile);
    Rewrite(F);
    Writeln(F, LastIP);
    CloseFile(F);
  except
    // Bỏ qua lỗi, không ảnh hưởng đến hoạt động chính
  end;
end;

procedure LoadLastIPFromFile;
var
  F: TextFile;
  S: string;
begin
  LastIPFile := Config.LogDir + 'lastIP.dat';
  if FileExists(LastIPFile) then
  begin
    try
      AssignFile(F, LastIPFile);
      Reset(F);
      Readln(F, S);
      CloseFile(F);
      LastIP := S;
    except
      LastIP := '';
    end;
  end
  else
    LastIP := '';
end;

function HttpGet(const URL: string): string;
var
  HTTP: TIdHTTP;
  Stream: TStringStream;
begin
  Result := '';
  if not IsNetworkAvailable then
  begin
    EnqueueLog('Network not available, skipping HTTP request to ' + URL);
    Exit;
  end;

  HTTP := TIdHTTP.Create(nil);
  Stream := TStringStream.Create('', TEncoding.UTF8);
  try
    HTTP.Request.UserAgent := 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';
    HTTP.Request.Accept := 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
    HTTP.Request.AcceptLanguage := 'en-US,en;q=0.5';
    HTTP.HandleRedirects := True;

    HTTP.ReadTimeout := Config.TimeoutSec * 1000;
    HTTP.ConnectTimeout := Config.TimeoutSec * 1000;

    try
      HTTP.Get(URL, Stream);
      Result := Stream.DataString;
    except
      on E: Exception do
        EnqueueLog('HTTP EXCEPTION for URL ' + URL + ': ' + E.Message);
    end;
  finally
    Stream.Free;
    HTTP.Free;
  end;
end;

function GetIPWithRetry: string;
var
  i, Retries: Integer;
  URL: string;
  Delay: DWORD;
  Success: Boolean;
  Content: string;
  IP: string;
begin
  Result := '';
  for i := 0 to High(Config.URLs) do
  begin
    URL := Trim(Config.URLs[i]);
    if URL = '' then Continue;
    Success := False;
    Retries := 0;
    Delay := 2000;
    while Retries < 3 do
    begin
      Content := HttpGet(URL);
      if Content <> '' then
      begin
        IP := ExtractIPFromText(Content, Config.DetectPattern);
        if IP <> '' then
        begin
          Result := IP;
          Success := True;
          Break;
        end;
      end;
      Sleep(Delay);
      Delay := Delay * 2;
      Inc(Retries);
    end;
    if Success then Break;
  end;
end;

function WorkerThread(lp: Pointer): DWORD; stdcall;
var
  IP: string;
begin
  while WaitForSingleObject(StopEvent, Config.IntervalMinutes * 60 * 1000) = WAIT_TIMEOUT do
  begin
    try
      IP := GetIPWithRetry;
      if IP <> '' then
      begin
        if IP <> LastIP then
        begin
          LastIP := IP;
          EnqueueLog('NEW IP: ' + IP);
          SaveLastIPToFile;
        end;
      end
      else
        EnqueueLog('ERROR: Cannot get IP from any URL');
    except
      on E: Exception do
        EnqueueLog('EXCEPTION in WorkerThread: ' + E.Message);
    end;
  end;
  Result := 0;
end;

function WatchdogThread(lp: Pointer): DWORD; stdcall;
var
  Worker: THandle;
  ThreadID: DWORD;
begin
  while WaitForSingleObject(StopEvent, 5000) = WAIT_TIMEOUT do
  begin
    Worker := CreateThread(nil, 0, @WorkerThread, nil, 0, ThreadID);
    WaitForSingleObject(Worker, INFINITE);
    CloseHandle(Worker);
    EnqueueLog('Worker restarted');
  end;
  Result := 0;
end;

procedure Handler(Ctrl: DWORD); stdcall;
begin
  if Ctrl = SERVICE_CONTROL_STOP then
    SetEvent(StopEvent);
end;

procedure ServiceMain(dwArgc: DWORD; lpszArgv: PLPWSTR); stdcall;
var
  ThreadID: DWORD;
  LoggerH, WatchdogH: THandle;
  Status: _SERVICE_STATUS;
  StatusHandle: SERVICE_STATUS_HANDLE;
begin
  LoadConfig;
  LogCS := TCriticalSection.Create;
  LogQueue := TStringList.Create;
  LogEvent := CreateEvent(nil, False, False, nil);
  StopEvent := CreateEvent(nil, True, False, nil);

  // Khôi phục LastIP từ file
  LoadLastIPFromFile;

  StatusHandle := RegisterServiceCtrlHandler(PWideChar(AServiceName), @Handler);
  FillChar(Status, SizeOf(Status), 0);
  Status.dwServiceType := SERVICE_WIN32_OWN_PROCESS;
  Status.dwCurrentState := SERVICE_START_PENDING;
  Status.dwControlsAccepted := 0;
  Status.dwWin32ExitCode := NO_ERROR;
  Status.dwCheckPoint := 0;
  Status.dwWaitHint := 30000;
  SetServiceStatus(StatusHandle, Status);

  LoggerH := CreateThread(nil, 0, @LoggerThread, nil, 0, ThreadID);
  WatchdogH := CreateThread(nil, 0, @WatchdogThread, nil, 0, ThreadID);

  Status.dwCurrentState := SERVICE_RUNNING;
  Status.dwControlsAccepted := SERVICE_ACCEPT_STOP;
  SetServiceStatus(StatusHandle, Status);

  WaitForSingleObject(StopEvent, INFINITE);

  Status.dwCurrentState := SERVICE_STOP_PENDING;
  SetServiceStatus(StatusHandle, Status);

  SetEvent(LogEvent);
  WaitForSingleObject(LoggerH, INFINITE);
  WaitForSingleObject(WatchdogH, INFINITE);

  CloseHandle(LoggerH);
  CloseHandle(WatchdogH);
  CloseHandle(LogEvent);
  CloseHandle(StopEvent);
  LogQueue.Free;
  LogCS.Free;

  Status.dwCurrentState := SERVICE_STOPPED;
  SetServiceStatus(StatusHandle, Status);
end;

procedure InstallService;
var
  SCManager, Service: THandle;
  FileName: string;
  ErrCode: DWORD;
begin
  FileName := '"' + ParamStr(0) + '"';
  SCManager := OpenSCManager(nil, nil, SC_MANAGER_ALL_ACCESS);
  if SCManager = 0 then
  begin
    ErrCode := GetLastError;
    MessageBox(0, PChar(Format('Cannot open Service Control Manager. Error %d: %s',
      [ErrCode, SysErrorMessage(ErrCode)])), 'Error', MB_ICONERROR);
    Exit;
  end;
  try
    Service := CreateService(
      SCManager,
      PWideChar(AServiceName),
      PWideChar(ADisplayName),
      SERVICE_ALL_ACCESS,
      SERVICE_WIN32_OWN_PROCESS,
      SERVICE_DEMAND_START,
      SERVICE_ERROR_NORMAL,
      PWideChar(FileName),
      nil, nil, nil, nil, nil);
    if Service = 0 then
    begin
      ErrCode := GetLastError;
      MessageBox(0, PChar(Format('Cannot create service. Error %d: %s',
        [ErrCode, SysErrorMessage(ErrCode)])), 'Error', MB_ICONERROR);
    end
    else
    begin
      LoadConfig;
      if Config.AutoStart then
        ChangeServiceConfig(Service, SERVICE_NO_CHANGE, SERVICE_AUTO_START,
                            SERVICE_NO_CHANGE, nil, nil, nil, nil, nil, nil, nil);
      MessageBox(0, 'Service installed successfully.', 'Information', MB_ICONINFORMATION);
      CloseServiceHandle(Service);
    end;
  finally
    CloseServiceHandle(SCManager);
  end;
end;

procedure UninstallService;
var
  SCManager, Service: THandle;
  ErrCode: DWORD;
begin
  SCManager := OpenSCManager(nil, nil, SC_MANAGER_ALL_ACCESS);
  if SCManager = 0 then
  begin
    ErrCode := GetLastError;
    MessageBox(0, PChar(Format('Cannot open Service Control Manager. Error %d: %s',
      [ErrCode, SysErrorMessage(ErrCode)])), 'Error', MB_ICONERROR);
    Exit;
  end;
  try
    Service := OpenService(SCManager, PWideChar(AServiceName), SERVICE_ALL_ACCESS);
    if Service = 0 then
    begin
      ErrCode := GetLastError;
      MessageBox(0, PChar(Format('Service not found. Error %d: %s',
        [ErrCode, SysErrorMessage(ErrCode)])), 'Error', MB_ICONERROR);
    end
    else
    begin
      if DeleteService(Service) then
        MessageBox(0, 'Service removed successfully.', 'Information', MB_ICONINFORMATION)
      else
      begin
        ErrCode := GetLastError;
        MessageBox(0, PChar(Format('Cannot delete service. Error %d: %s',
          [ErrCode, SysErrorMessage(ErrCode)])), 'Error', MB_ICONERROR);
      end;
      CloseServiceHandle(Service);
    end;
  finally
    CloseServiceHandle(SCManager);
  end;
end;

end.