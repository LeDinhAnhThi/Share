unit uLogViewer;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs,
  Vcl.StdCtrls, Vcl.ExtCtrls, System.IniFiles, System.RegularExpressions;

type
  TfrmLogViewer = class(TForm)
    lblLogFile: TLabel;
    cboLogFile: TComboBox;
    btnBrowse: TButton;
    lblPublicIP: TLabel;
    edtPublicIP: TEdit;
    btnRefresh: TButton;
    OpenDialog1: TOpenDialog;
    procedure btnBrowseClick(Sender: TObject);
    procedure btnRefreshClick(Sender: TObject);
    procedure cboLogFileChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    FIni: TIniFile;
    procedure LoadRecentPaths;
    procedure SaveRecentPath(const Path: string);
    function ExtractLatestIPFromFile(const FileName: string): string;
  public
  end;

var
  frmLogViewer: TfrmLogViewer;

implementation

{$R *.dfm}

procedure TfrmLogViewer.FormCreate(Sender: TObject);
begin
  OpenDialog1.Filter := 'Log files (*.txt)|*.txt|All files (*.*)|*.*';
  OpenDialog1.Options := [ofFileMustExist, ofEnableSizing];

  // Load recently used paths from INI
  FIni := TIniFile.Create(ChangeFileExt(ParamStr(0), '.ini'));
  try
    LoadRecentPaths;
  except
    // If INI reading fails, ignore
  end;
end;

procedure TfrmLogViewer.LoadRecentPaths;
var
  i: Integer;
  Path: string;
begin
  cboLogFile.Items.Clear;
  for i := 1 to 10 do
  begin
    Path := FIni.ReadString('Recent', 'Path' + IntToStr(i), '');
    if Path <> '' then
      cboLogFile.Items.Add(Path);
  end;
  // If there is at least one path, select the first
  if cboLogFile.Items.Count > 0 then
    cboLogFile.ItemIndex := 0;
end;

procedure TfrmLogViewer.SaveRecentPath(const Path: string);
var
  i: Integer;
  ExistingIndex: Integer;
begin
  // Remove if already exists
  ExistingIndex := cboLogFile.Items.IndexOf(Path);
  if ExistingIndex >= 0 then
    cboLogFile.Items.Delete(ExistingIndex);

  // Insert at top
  cboLogFile.Items.Insert(0, Path);
  // Keep only last 10 entries
  while cboLogFile.Items.Count > 10 do
    cboLogFile.Items.Delete(10);
  cboLogFile.ItemIndex := 0;

  // Save to INI
  for i := 0 to cboLogFile.Items.Count - 1 do
    FIni.WriteString('Recent', 'Path' + IntToStr(i+1), cboLogFile.Items[i]);
  // Clear any extra entries
  for i := cboLogFile.Items.Count + 1 to 10 do
    FIni.WriteString('Recent', 'Path' + IntToStr(i), '');
  FIni.UpdateFile;
end;

procedure TfrmLogViewer.btnBrowseClick(Sender: TObject);
begin
  if OpenDialog1.Execute then
  begin
    cboLogFile.Text := OpenDialog1.FileName;
    SaveRecentPath(OpenDialog1.FileName);
    // Automatically refresh IP after selecting new file
    btnRefreshClick(nil);
  end;
end;

function TfrmLogViewer.ExtractLatestIPFromFile(const FileName: string): string;
var
  Lines: TStringList;
  i: Integer;
  Line: string;
  Regex: TRegEx;
  Match: TMatch;
begin
  Result := '';
  if not FileExists(FileName) then
    Exit;

  Lines := TStringList.Create;
  try
    Lines.LoadFromFile(FileName);
    // Search from end to start for the last line containing "NEW IP:"
    for i := Lines.Count - 1 downto 0 do
    begin
      Line := Lines[i];
      if Pos('NEW IP:', Line) > 0 then
      begin
        // Extract IP using regex (IPv4 or IPv6)
        // IPv4 pattern
        Regex := TRegEx.Create('\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b');
        Match := Regex.Match(Line);
        if Match.Success then
        begin
          Result := Match.Value;
          Break;
        end;
        // If IPv4 not found, try IPv6 pattern (simple)
        Regex := TRegEx.Create('(?:[0-9a-fA-F:]+)');
        Match := Regex.Match(Line);
        if Match.Success then
        begin
          Result := Match.Value;
          Break;
        end;
      end;
    end;
  finally
    Lines.Free;
  end;
end;

procedure TfrmLogViewer.btnRefreshClick(Sender: TObject);
var
  IP: string;
begin
  if cboLogFile.Text = '' then
  begin
    edtPublicIP.Text := '(No file selected)';
    Exit;
  end;

  if not FileExists(cboLogFile.Text) then
  begin
    edtPublicIP.Text := '(File not found)';
    Exit;
  end;

  IP := ExtractLatestIPFromFile(cboLogFile.Text);
  if IP <> '' then
    edtPublicIP.Text := IP
  else
    edtPublicIP.Text := '(No IP found in log)';
end;

procedure TfrmLogViewer.cboLogFileChange(Sender: TObject);
begin
  // Auto refresh when user selects a different file from the combo box
  btnRefreshClick(nil);
end;

end.