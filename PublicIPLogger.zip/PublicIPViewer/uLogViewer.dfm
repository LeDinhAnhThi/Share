object frmLogViewer: TfrmLogViewer
  Left = 0
  Top = 0
  Caption = 'Public IP Log Viewer'
  ClientHeight = 150
  ClientWidth = 500
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lblLogFile: TLabel
    Left = 16
    Top = 24
    Width = 63
    Height = 13
    Caption = 'Log file path:'
  end
  object lblPublicIP: TLabel
    Left = 16
    Top = 72
    Width = 44
    Height = 13
    Caption = 'Public IP:'
  end
  object cboLogFile: TComboBox
    Left = 96
    Top = 21
    Width = 300
    Height = 21
    TabOrder = 0
    OnChange = cboLogFileChange
  end
  object btnBrowse: TButton
    Left = 404
    Top = 19
    Width = 75
    Height = 25
    Caption = 'Browse...'
    TabOrder = 1
    OnClick = btnBrowseClick
  end
  object edtPublicIP: TEdit
    Left = 96
    Top = 69
    Width = 300
    Height = 21
    ReadOnly = True
    TabOrder = 2
  end
  object btnRefresh: TButton
    Left = 404
    Top = 67
    Width = 75
    Height = 25
    Caption = 'Refresh'
    TabOrder = 3
    OnClick = btnRefreshClick
  end
  object OpenDialog1: TOpenDialog
    Filter = 'Log files (*.txt)|*.txt|All files (*.*)|*.*'
    Options = [ofFileMustExist, ofEnableSizing]
    Left = 440
    Top = 112
  end
end
