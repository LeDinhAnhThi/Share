program LogViewer;

uses
  Vcl.Forms,
  uLogViewer in 'uLogViewer.pas' {frmLogViewer};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmLogViewer, frmLogViewer);
  Application.Run;
end.